import uuid
import asyncio
from .messages import (CompletionClientStreamMessage,
                       InvocationClientStreamMessage, StreamItemMessage)


class Subject(object):
    def __init__(self):
        self.connection = None
        self.target = None
        self.invocation_id = str(uuid.uuid4())
        self.lock = asyncio.Lock()

    def check(self):
        if self.connection is None or self.target is None or self.invocation_id is None:
            raise ValueError(
                "subject must be passed as an argument to a send function. hub_connection.send([method],[subject]")

    async def next(self, item):
        self.check()
        async with self.lock:
            await self.connection.hub.send(StreamItemMessage(
                {},
                self.invocation_id,
                item
            ))

    async def start(self):
        self.check()
        async with self.lock:
            await self.connection.hub.send(InvocationClientStreamMessage(
                {},
                [self.invocation_id],
                self.target,
                []))

    async def complete(self):
        self.check()
        async with self.lock:
            await self.connection.hub.send(CompletionClientStreamMessage(
                {},
                self.invocation_id))
